Design Thinking and GAE Tutorial for Orbital
-------------------------------------------

 * DesignThinking.pptx contains the slides for the Design Thinking tutorial
 * DT_Session.pptx contains the slides for running the Design Thinking exercise
 * GAE.pptx contains the slides for the GAE Tutorial
 * FightHazeMockup.pptx contains the powerpoint mockup of the app built in the GAE tutorial
 * FightHazeBasic is the directory used in the tutorial
 * FightHaze contains the a more complete version of the app with cron jobs for getting haze data from data.gov.sg and sending email reminders
